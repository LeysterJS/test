package de.tbag.gbd.combat;

/**
 * @author Samuel Ratzel
 * @version 1.0
 * @since 28.02.24
 */

public enum WeaponType {
    SPELL,
    LONG_RANGE,
    SHORT_RANGE
}
