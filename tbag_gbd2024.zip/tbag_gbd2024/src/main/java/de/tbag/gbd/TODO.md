Add Drops to enemy death
> - Enemy max health / 10 = Amount of gold
> - Drop weapon holding
> - drop amount of potions holding (select random between small, medium, big)

Add shop system
> - Add a Merchant to sell your weapon (price set by Damage, type and crit chance)
> - Add a posibillity for the Dev to create a new merchant with their own shop and price
> - Add weapon items, healt boosts (more max health), pocket boost (more max potions and weapons)

Add "run away"
> - For enemy low chance, will most likely die by trying
> - For player always an option, lower chances of success when less health
> - Penalty?!