package de.tbag.gbd.potions;

/**
 *
 * @author Samuel Ratzel
 * @since 29.02.24
 * @version 1.0
 *
 */

public enum PotionsType {

    //Heal Pots
    LARGE_POT,
    MEDIUM_POT,
    SMALL_POT,


    //Strength Pots
    LARGE_STRENGTH_POT,
    MEDIUM_STRENGTH_POT,
    SMALL_STRENGTH_POT,


}
